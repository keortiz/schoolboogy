<?class RSS
{
    public function RSS()
    {
    require_once ('includes/db.inc.php');
    }
    public function getFeed()
    {
    return $this->getDetails(). $this->getItems();
    }
    private function dbConnect()
    {
    DEFINE ('LINK',mysql_connect(DB_HOST,DB_USER,DB_PASSWORD));
    }
    private function getDetails()
    {
    
    }
}