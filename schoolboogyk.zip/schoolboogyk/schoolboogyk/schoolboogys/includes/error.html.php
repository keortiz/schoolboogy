<!doctype html>
<html lang= "en">
<head>
<meta charset= "utf8">
<title>script error></title>
</head>
<body>
<p>
<?php echo $error;?>
</p>
</body>
</html>
