<div id="information">
	<h3>CLASSES</h3>	
			<div>	
				<?php include 'includes/classes.inc.php';?>
		</div>			
		
<h3>ACTIVITIES<h3>
		<div >			
				stuff				
		</div>
<h3>STUDY ROOM</h3>
		<div >			
				stuff				
		</div>
<h3>PROJECT ROOMS</h3>
		<div >			
				stuff				
		</div>
<h3>ACHIEVEMENT BOARD</h3>
		<div >			
				stuff				
		</div>
<h3>WHO IS ONLINE</h3>
		<div >			
				stuff				
</div>
</div>