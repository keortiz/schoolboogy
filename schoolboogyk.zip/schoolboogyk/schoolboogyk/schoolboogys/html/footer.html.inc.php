
		<div id="footer">
			&copy SchoolBoogy Corporation. All rights reserved
		</div>

