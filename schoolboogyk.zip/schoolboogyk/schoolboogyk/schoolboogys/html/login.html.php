
  	<div id=toppanel>
			<?php include 'html/header.html.php';?>	
	</div>
	
	
		

	<form id="login" action="" method="">
	
	<p>
	
	<div class="row">
	<label for="username">Username</label>
	<input type="text" id="username" name=""></br></br>
	</div>

	<div class="row">
	<label for="password">Password</label>
	<input type="password" id="password" name=""></br></br>
	</div>
	
	<div class="row">
	<label for="pincode">Access PIN</label>
	<input type="password" id="pincode" name=""></br></br>	
	</div>

	</p>
	</form>


			<?php	include 'html/footer.html.inc.php'; ?>