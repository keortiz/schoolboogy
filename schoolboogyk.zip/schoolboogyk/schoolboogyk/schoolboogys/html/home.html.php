<table width="100%" border="0">
  <tbody >
			<?php include 'html/header.html.php';?>
		
	      <td id="mebanner">	
	
			<?php	include 'html/banner.html.php'; ?>	
	
	
   
   </td>		
					
    <tr>
     
      <table width="100%" border="0">
  <tbody>
  

	  
    <tr>
     
      <td class="dabordersides">    		
    		<div class="pheader">DAILY ACTIVITIES</div>	
			<?php	include 'includes/activities.inc.php'; ?>  		
			</td>
      <td class="daborder"> 
			<?php include 'includes/news.inc.php';?>	
	</td>
      <td class="dabordersides">		
	    	<div class="pheader">INFORMATION & RESOURCES</div>	
		  <?php include 'includes/information.inc.php';?>
					
		</td>
    </tr>
  </tbody>
</table>

    </tr>
    <tr>
      <td><?php	include 'html/footer.html.inc.php'; ?></td>
    </tr>
  </tbody>
</table>
 	

 	
 	
	

	
	

			