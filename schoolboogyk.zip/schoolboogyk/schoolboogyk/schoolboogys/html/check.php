<?php
    // Connects to your Database
    mysql_connect("localhost:3306", "root", "") or die(mysql_error());
    mysql_select_db("schoolboogy") or die(mysql_error());
    
    
    
    // SQL query
    $strSQL = "SELECT sb_posts.postitem,sb_posts.timedate,sb_posts.groupID,sb_posts.userID,sb_posts.fname,sb_posts.lname FROM sb_posts where groupID = 1 order by sb_posts.timedate DESC LIMIT 1";
    
    // Execute the query (the recordset $rs contains the result)
    $rs = mysql_query($strSQL);
    
    // Loop the recordset $rs
    // Each row will be made into an array ($row) using mysql_fetch_array
    while($row = mysql_fetch_array($rs)) {
        
        $atime = $row['timedate'];
        
        $tizz = $_GET['tim'];
        echo $tizz;
        $dsff = $row['timedate'];;
        
        $duff = date("Y-m-d H:i:s");
        
        //convert the date-time into seconds so we can extract 6 seconds from it
        $six = strtotime(date("Y-m-d H:i:s"))-6;

        
        //convert the latest image date-time too from database so we can compare it
        $sox = strtotime("$dsff");

        if ($six > $sox)
        {
            echo "hi";
            
           echo '<script type="text/javascript">$(document).ready( function(){ $("#quote a").load("display.php?timm='. $tizz .'"); } ); </script>';
        }
    }
    
    // Close the database connection
    mysql_close();
    
    
    ?>
