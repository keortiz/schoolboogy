<!DOCTYPE html>
<html>
<head></head>
<body>
<script type="text/javascript" src="js/jquery.js"></script>

<script type="text/javascript">
        $(document).ready(function(){


            setInterval(function(){
                $("#quotex a").load("check.php?tim=<?php print date("Y-m-d H:i:s"); ?>");
            }, 5000);

        });
        </script>

        <div id="quote"><a></a></div>


        <div id="quotex"><a></a></div>
    </body></html>