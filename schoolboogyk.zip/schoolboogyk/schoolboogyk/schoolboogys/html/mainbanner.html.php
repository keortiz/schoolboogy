<div id="profileimg">



</div>
</div>

<div id="infobox">
<p>TUESDAY <br> 
05/15/2017 <br>
CLOUDY <br>
11:55 AM <br>
PERIOD: 3
</p>
</div>
<?php








?>









