<?php
    $tipp = $_GET["timm"];
    // Connects to your Database
    mysql_connect("localhost:3306", "root", "") or die(mysql_error());
    mysql_select_db("schoolboogy") or die(mysql_error());
    
    
    
    
    // SQL query
    $strSQL = "SELECT sb_posts.postitem,sb_posts.timedate,sb_posts.groupID,sb_posts.userID,sb_posts.fname,sb_posts.lname FROM sb_posts where groupID = 1 and timedate > '$tipp' order by sb_posts.timedate DESC";
    // Execute the query (the recordset $rs contains the result)
    $rs = mysql_query($strSQL);
    
    // Loop the recordset $rs
    // Each row will be made into an array ($row) using mysql_fetch_array
    while($row = mysql_fetch_array($rs)) {
        //guid is the column where the image url is located in the wordpress database table
        $atime = $row['postitem'];
        
        echo  $atime;
    }
    // Close the database connection
    mysql_close();
    
    
    ?>
