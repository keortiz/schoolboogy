
    
    <?php 

	echo '<button id="1" class="curricula" onclick=getTextbook()><br><i class="fa fa-book" aria-hidden="true"></i>    TextBook<br><br></button>';
	    echo '<br>';
	echo '<button id="2" class="curricula" onclick=getTutorial()><br><i class="fa fa-video-camera" aria-hidden="true"></i>    Video Tutorials<br><br></button>';
	    echo '<br>';
	echo '<button id="3" class="curricula" onclick=getChalktalk()><br><i class="fa fa-pencil-square" aria-hidden="true"></i>    Chalk Talks<br><br></button>';	
	    echo '<br>';
	echo '<button id="4" class="curricula" onclick=getExercises()><br><i class="fa fa-puzzle-piece" aria-hidden="true"></i>    Practice Exercises<br><br></button>';
	    echo '<br>';
	echo '<button id="5" class="curricula" onclick=getLearnmore()><br><i class="fa fa-map" aria-hidden="true"></i>    Learn More<br><br></button>';
	    echo '<br>';
	echo '<button id="6" class="curricula" onclick=getHomework()><br><i class="fa fa-tasks" aria-hidden="true"></i>    Homework<br><br></button>';
	    echo '<br>';
	echo '<button id="7" class="curricula" onclick=getAssessment()><br><i class="fa fa-crosshairs" aria-hidden="true"></i>    Assessment<br><br></button>';
	    echo '<br>';
	echo '<button id="8" class="curricula" onclick=getArchive()><br><i class="fa fa-archive" aria-hidden="true"></i>    Archive<br><br></button>';
	    echo '<br>';
   
    ?>


	 
