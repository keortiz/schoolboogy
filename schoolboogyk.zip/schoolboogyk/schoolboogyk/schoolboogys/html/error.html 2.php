<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Oops! Something went wrong! Sorry</title>
  </head>
  <body>
    <p>
      <?php echo $error; ?>
    </p>
  </body>
</html>