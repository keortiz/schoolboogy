

<table width="100%" border="1">
  <tbody >
			<?php include 'html/header.html.php';?>	
 
    
      <td id="mebanner">	
	
			<?php	include 'html/banner.html.php'; ?>	
	
	
   
   </td>
    
    <tr>
  <table width="100%" border="0">
  <tbody>
    <tr>
      <td class="dabordersides">
		
	
    		<div class="pheader">MY PROFILE</div>	
    		
			<?php	include 'includes/me.inc.php'; ?>
			
			
	</td>
	
      <td class="daborder"> 	
			<?php include 'html/posts.html.php';?>	
	</td>

      <td class="dabordersides">
          		<div class="pheader">COMMUNITIES</div>		
			<?php include 'html/communities.html.php';?>		
		</td>
    </tr>
  </tbody>
</table>

    </tr>
    <tr>
      <td><?php	include 'html/footer.html.inc.php'; ?></td>
    </tr>
  </tbody>
</table>
 
