<div class="cheader">Course Summary</div>	
<div class="notes"></div>
<div class="ask"></div>	
<div id="sb_content">

</div>