		
	

  







var $lessonAsset = "";
		var $last = "lessons";
		var $b = "me";
		var $page = "home";
		var $courseID= "";
		var $groupID = "";

		
		
		function setAsset($a) {
			$lessonAsset = $a;
			getLessonsummary()
			setSelect();

			
			function setSelect() 
			{
			document.getElementById($a).style.backgroundColor = "#246aa8";
			document.getElementById($b).style.backgroundColor = "#4291d7";
			$b = $a;
					
			};



			

			
		return $lessonAsset;		
		}
		
		function setSummary($a) {
			$lessonAsset = $a;
			getSummary();
		return $lessonAsset;		
		}

 
  		( function() 
  		{
    		var icons = 
    			{
      				header: "ui-icon-circle-arrow-e",
      				activeHeader: "ui-icon-circle-arrow-s"
    			};
    	$( "#accordion" ).accordion
    		({
      			icons: icons
   			 });
    	$( "#toggle" ).button().on( "click", function() 
    		{
      			if ( $( "#accordion" ).accordion( "option", "icons" ) ) {
        		$( "#accordion" ).accordion( "option", "icons", null );
      		} 
      	else 
      		{
        		$( "#accordion" ).accordion( "option", "icons", icons );
      		}
    		});
  		});
  		
  		
  		
  		 		$( function() 
  		{
    		var icons = 
    			{
      				header: "ui-icon-circle-arrow-e",
      				activeHeader: "ui-icon-circle-arrow-s"
    			};
    	$( "#information" ).accordion
    		({
      			icons: icons
   			 });
    	$( "#toggle" ).button().on( "click", function() 
    		{
      			if ( $( "#information" ).accordion( "option", "icons" ) ) {
        		$( "#information" ).accordion( "option", "icons", null );
      		} 
      	else 
      		{
        		$( "#information" ).accordion( "option", "icons", icons );
      		}
    		});
  		});
  		
  		  		$( function() 
  		{
    		var icons = 
    			{
      				header: "ui-icon-circle-arrow-e",
      				activeHeader: "ui-icon-circle-arrow-s"
    			};
    	$( "#accordion1" ).accordion
    		({
      			icons: icons
   			 });
    	$( "#toggle" ).button().on( "click", function() 
    		{
      			if ( $( "#accordion1" ).accordion( "option", "icons" ) ) {
        		$( "#accordion1" ).accordion( "option", "icons", null );
      		} 
      	else 
      		{
        		$( "#accordion1" ).accordion( "option", "icons", icons );
      		}
    		});
  		});
  		
  		  		$( function() {
    		$( "#tabs" ).tabs();
  		} );
  		
  		
  	  		function getLessonsummary() {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "course/" + $lessonAsset + "/lessonsummary.html.php", true);
    xhr.send();
    xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("content").innerHTML=xhr.responseText;
	
	    
	    
	 }}}	
  		
  		function classpostings(x) {
		groupID = x;
		console.log(groupID);
	    var xhr = new XMLHttpRequest();
    	xhr.open("POST", "includes/classposts.inc.php?groupID=" + groupID, true);
    	xhr.send();
    	xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("postings").innerHTML=xhr.responseText;	
		content = '<input id = type="button" value="POST" onclick="get('+ groupID + ')" />';
	    document.getElementById("groupPst").innerHTML = content;    

            poll = function(){
                $.ajax({
              
                
                });
            }
            pollInterval = setInterval(function(){
               poll()
            },2000);
 
	 }}
	    
	 }

            
	 
	   	function getgroup() {

	    var xhr = new XMLHttpRequest();
    	xhr.open("POST", "includes/classposts.inc.php", true);
    	xhr.send();
    	xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("postings").innerHTML=xhr.responseText;
	
	
	    
	 }}
	    
	 }	
	 

  		function getSummary() {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "course/" + $lessonAsset + "/summary.html.php", true);
    xhr.send();
    xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("content").innerHTML=xhr.responseText;
	 }}}
	 
	 
	 	function getTextbook() {
	document.getElementById("1").style.backgroundColor = "#246aa8";	 					 	
	document.getElementById($last).style.backgroundColor = "#4291d7";
	$last = "1";	 	
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "course/" + $lessonAsset + "/1/textbooks.html.php", true);
    xhr.send();
    xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("content").innerHTML=xhr.responseText;
	 }}}
	 
	 	function getTutorial() {
	 document.getElementById("2").style.backgroundColor = "#246aa8";	 					 	
	document.getElementById($last).style.backgroundColor = "#4291d7";
	$last = "2";
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "course/" + $lessonAsset + "/2/tutorials.html.php", true);
    xhr.send();
    xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("content").innerHTML=xhr.responseText;
	 }}}
	 
	 	function getChalktalk() {
	 document.getElementById("3").style.backgroundColor = "#246aa8";	 					 	
	document.getElementById($last).style.backgroundColor = "#4291d7";
	$last = "3";	
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "course/" + $lessonAsset + "/3/chalktalks.html.php", true);
    xhr.send();
    xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("content").innerHTML=xhr.responseText;
	 }}}
	 
	 	function getExercises() {
	 document.getElementById("4").style.backgroundColor = "#246aa8";	 					 	
	document.getElementById($last).style.backgroundColor = "#4291d7";
	$last = "4";	
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "course/" + $lessonAsset + "/4/exercises.html.php", true);
    xhr.send();
    xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("content").innerHTML=xhr.responseText;
	 }}}
	 
	 	function getLearnmore() {
	document.getElementById("5").style.backgroundColor = "#246aa8";	 					 	
	document.getElementById($last).style.backgroundColor = "#4291d7";
	$last = "5";	
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "course/" + $lessonAsset + "/5/learning.html.php", true);
    xhr.send();
    xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("content").innerHTML=xhr.responseText;
	 }}}
	 	 
	 	function getHomework() {
	document.getElementById("6").style.backgroundColor = "#246aa8";	 					 	
	document.getElementById($last).style.backgroundColor = "#4291d7";
	$last = "6";	
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "course/" + $lessonAsset + "/6/homework.html.php", true);
    xhr.send();
    xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("content").innerHTML=xhr.responseText;
	 }}}

	 
	 	function getAssessment() {
	document.getElementById("7").style.backgroundColor = "#246aa8";	 					 	
	document.getElementById($last).style.backgroundColor = "#4291d7";
	$last = "7";	
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "course/" + $lessonAsset + "/7/assessment.html.php", true);
    xhr.send();
    xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	    document.getElementById("content").innerHTML=xhr.responseText;
	 }}}
	 
	 function openCity(evt, cityName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the link that opened the tab
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}



