<!DOCTYPE html>
<html lang="en">
  <head>
  	<link rel="stylesheet" type="text/css" href="styles/stylesheet.css">
   	<link rel="stylesheet" type="text/css" href="jquery-ui/jquery-ui.css"> 
	<link rel="stylesheet" type="text/css" href="jquery-ui/jquery-ui.structure.css">
    <link rel="stylesheet" type="text/css" href="jquery-ui/jquery-ui.theme.css">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
<script src="js/jquery.js"></script>
    <script src="jquery-ui/jquery-ui.js"></script>  
	  
  <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
  <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script> 	  
	  
    <script src="js/script.js"></script>    

    <meta charset="utf-8">
    
    <title>Schoolboogy Student Edition</title>


  </head>

  <body>

	<?php
		include 'includes/db.inc.php';
		include 'html/home.html.php';

	?>


  </body>
  
</html>

