<!doctype html>
<html  lang="en">
<head>
<meta charset="UTF-8">
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="styles/login.css">
	

<script src="js/jquery.js"></script>
<script src="jquery-ui/jquery-ui.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/script.js"></script>	
	

    
	
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	
<title>SchoolBoogy Student</title>

</head>



<body id="body">
	<?php
		include 'html/login.php';

	?>
	


</body>
</html>

